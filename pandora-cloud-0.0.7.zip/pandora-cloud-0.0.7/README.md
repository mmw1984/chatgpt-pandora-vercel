# Pandora-Cloud

![Python version](https://img.shields.io/badge/python-%3E%3D3.7-green)
[![Issues](https://img.shields.io/github/issues-raw/pengzhile/pandora-cloud)](https://github.com/pengzhile/pandora-cloud/issues)
[![Commits](https://img.shields.io/github/last-commit/pengzhile/pandora-cloud/master)](https://github.com/pengzhile/pandora-cloud/commits/master)
[![PyPi](https://img.shields.io/pypi/v/pandora-cloud.svg)](https://pypi.python.org/pypi/pandora-cloud)
[![Downloads](https://static.pepy.tech/badge/pandora-cloud)](https://pypi.python.org/pypi/pandora-cloud)

[![PyPi workflow](https://github.com/pengzhile/pandora-cloud/actions/workflows/python-publish.yml/badge.svg)](https://github.com/pengzhile/pandora-cloud/actions/workflows/python-publish.yml)

### A package for Pandora-ChatGPT